package bensalcie.likesyou.org.brainverseirrigation.ui.dashboard;

import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;

import bensalcie.likesyou.org.brainverseirrigation.R;
import bensalcie.likesyou.org.brainverseirrigation.reciever.AlarmReciever;
import bensalcie.likesyou.org.brainverseirrigation.schedular.CustomCalendarView;
import mehdi.sakout.fancybuttons.FancyButton;

public class DashboardFragment extends Fragment {

    private FancyButton pumpone,pumptwo,pumpthree,pumpfour;
    private boolean p1=false,p2=false,p3=false,p4=false;
    private DatabaseReference pumpsDb;
    private Button btnSchedule;

    private int notificationId=1;
    private CustomCalendarView calendarView;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_dashboard, container, false);
        String dbroot = "BRAINVERSE/IOTIRRIGATION/PUMPS";
        pumpsDb= FirebaseDatabase.getInstance().getReference().child(dbroot);
        pumpone= root.findViewById(R.id.pumpone);
        calendarView=root.findViewById(R.id.custom_calendar_view);
        pumptwo= root.findViewById(R.id.pumptwo);
        btnSchedule=root.findViewById(R.id.btnSchedule);
        pumpthree= root.findViewById(R.id.pumpthree);
        pumpfour= root.findViewById(R.id.pumpfour);
        pumpone.setText(getContext().getString(R.string.pump_loading));
        pumptwo.setText(getContext().getString(R.string.pump_loading));
        pumpthree.setText(getContext().getString(R.string.pump_loading));
        pumpfour.setText(getContext().getString(R.string.pump_loading));

        getbuttonStatus(pumpone,pumptwo,pumpthree,pumpfour);

        handleClicks();
        return root;
    }

    private void handleClicks() {
        pumpone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (p1) {
                    changeState(1,0,pumpone);
                }else {
                    changeState(1,1,pumpone);

                }
            }
        });
        pumptwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (p2) {
                    changeState(2,0,pumptwo);
                }else {
                    changeState(2,1,pumptwo);

                }
            }
        });
        pumpthree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (p3) {
                    changeState(3,0,pumpthree);
                }else {
                    changeState(3,1,pumpthree);

                }
            }
        });
        pumpfour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (p4) {
                    changeState(4,0,pumpfour);
                }else {
                    changeState(4,1,pumpfour);

                }
            }
        });
    }

    private void changeState(final int pump, final int status, final FancyButton button) {
        pumpsDb.child(""+pump).setValue(status).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()){
                    if (status==1){
                        updateButtons(pumpone, pumptwo, pumpthree, pumpfour);
                    }else {
                        updateButtons(pumpone, pumptwo, pumpthree, pumpfour);
                    }
                }
            }
        });
    }

    private void getbuttonStatus(final FancyButton pumpone, final FancyButton pumptwo, final FancyButton pumpthree, final FancyButton pumpfour) {
        pumpsDb.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
               if (dataSnapshot.exists()){

                   String btn1stat=dataSnapshot.child("1").getValue().toString();
                   p1= btn1stat.equals("1");
                   String btn2stat=dataSnapshot.child("2").getValue().toString();
                   p2= btn2stat.equals("1");

                   String btn3stat=dataSnapshot.child("3").getValue().toString();
                   p3= btn3stat.equals("1");

                   String btn4stat=dataSnapshot.child("4").getValue().toString();
                   p4= btn4stat.equals("1");
                   updateButtons(pumpone,pumptwo,pumpthree,pumpfour);
               }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    private void updateButtons(FancyButton pumpone, FancyButton pumptwo, FancyButton pumpthree, FancyButton pumpfour) {

        if (p1){

            pumpone.setBackgroundColor(Color.parseColor("#73b730"));
            pumpone.setFocusBackgroundColor(Color.parseColor("#73b730"));
            pumpone.setTextColor(Color.parseColor("#ffffff"));
            pumpone.setText("PUMP ONE ON");

        }else {
            pumpone.setBackgroundColor(Color.parseColor("#4E4E50"));
           pumpone.setFocusBackgroundColor(Color.parseColor("#4E4E50"));
            pumpone.setTextColor(Color.parseColor("#73b730"));
            pumpone.setText("PUMP ONE OFF");

        }
        if (p2){
           pumptwo.setBackgroundColor(Color.parseColor("#73b730"));
            pumptwo.setFocusBackgroundColor(Color.parseColor("#73b730"));

            pumptwo.setTextColor(Color.parseColor("#ffffff"));
            pumptwo.setText("PUMP TWO ON");

        }else {
            pumptwo.setBackgroundColor(Color.parseColor("#4E4E50"));
            pumptwo.setFocusBackgroundColor(Color.parseColor("#4E4E50"));
            pumptwo.setTextColor(Color.parseColor("#73b730"));
            pumptwo.setText("PUMP TWO OFF");

        }
        if (p3){
            pumpthree.setBackgroundColor(Color.parseColor("#73b730"));
            pumpthree.setFocusBackgroundColor(Color.parseColor("#73b730"));
            pumpthree.setTextColor(Color.parseColor("#ffffff"));
            pumpthree.setText("PUMP THREE ON");

        }else {
            pumpthree.setBackgroundColor(Color.parseColor("#4E4E50"));
            pumpthree.setFocusBackgroundColor(Color.parseColor("#4E4E50"));
            pumpthree.setTextColor(Color.parseColor("#73b730"));
            pumpthree.setText("PUMP THREE OFF");

        }
        if (p4){
            pumpfour.setBackgroundColor(Color.parseColor("#73b730"));
            pumpfour.setFocusBackgroundColor(Color.parseColor("#73b730"));
            pumpfour.setTextColor(Color.parseColor("#ffffff"));
            pumpfour.setText("PUMP FOUR ON");

        }else {
            pumpfour.setBackgroundColor(Color.parseColor("#4E4E50"));
            pumpfour.setFocusBackgroundColor(Color.parseColor("#4E4E50"));
            pumpfour.setTextColor(Color.parseColor("#73b730"));
            pumpfour.setText("PUMP FOUR OFF");

        }

    }



    private void bringPopup(View v) {
        final Dialog d=new Dialog(getContext());
        d.setContentView(R.layout.bottom_sheet);

        ImageButton btnClose=d.findViewById(R.id.btnClose);

        final EditText etDescription;
        final RadioButton rb1,rb2,rb3,rb4;
        final TimePicker tp;
        Button btnAdTask;
        etDescription=d.findViewById(R.id.etTaskName);
        rb1=d.findViewById(R.id.rb1);
        rb2=d.findViewById(R.id.rb2);
        rb3=d.findViewById(R.id.rb3);
        rb4=d.findViewById(R.id.rb4);
        btnAdTask=d.findViewById(R.id.btnAddTask);
        tp=d.findViewById(R.id.timePicker);


        btnAdTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String desc=etDescription.getText().toString();
                int hour=tp.getCurrentHour();
                int minute=tp.getCurrentMinute();
                //create TIME
                Calendar cal=Calendar.getInstance();
                cal.set(Calendar.HOUR_OF_DAY,hour);
                cal.set(Calendar.MINUTE,minute);

                cal.set(Calendar.SECOND,0);

                long alarmStartTime=cal.getTimeInMillis();



                String pump_no = null;
                if (rb1.isChecked()){
                    pump_no="1";
                }else if (rb2.isChecked()){
                    pump_no="2";
                }else if (rb3.isChecked()){
                    pump_no="3";
                }else if (rb4.isChecked()){
                    pump_no="4";
                }


                if (!TextUtils.isEmpty(desc) && hour!=0 && minute!=0  &&!TextUtils.isEmpty(pump_no)){


                    createTask(desc,pump_no,hour,minute,alarmStartTime,d);
                }else {
                    Toast.makeText(getContext(), "Check your task again...", Toast.LENGTH_SHORT).show();
                }

            }
        });



        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
            }
        });
        d.show();
    }

    private void createTask(String desc, String pump_no, int hour, int minute, long alarmStartTime, Dialog d) {

        Intent intent=new Intent(getContext(), AlarmReciever.class);
        intent.putExtra("notificationId",notificationId);
        intent.putExtra("description",desc+" \n"+pump_no);
        //GET BORADCAST CONTEXT
        PendingIntent alarmIntent=PendingIntent.getBroadcast(getContext(),0,intent,PendingIntent.FLAG_CANCEL_CURRENT);

        assert getContext()!=null;
        AlarmManager alarm=(AlarmManager)getContext().getSystemService(Context.ALARM_SERVICE);

        assert alarm != null;
        alarm.set(AlarmManager.RTC_WAKEUP,alarmStartTime,alarmIntent);
        Toast.makeText(getContext(), "Done: "
                , Toast.LENGTH_SHORT).show();
        d.dismiss();


        /*

        alarm.cancel(alarminten)

         */
    }

}