package bensalcie.likesyou.org.brainverseirrigation.schedular;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import bensalcie.likesyou.org.brainverseirrigation.R;

public class CustomCalendarView extends LinearLayout {
    ImageButton nextBtn,previousBtn;
    TextView tvCurrentDate;
    GridView gridView;
    private static final int MAX_CALENDAR_DATES=42;
    Calendar calendar=Calendar.getInstance(Locale.ENGLISH);
    Context context;
    List<Date> dates=new ArrayList<>();
    List<Events> eventsList=new ArrayList<>();
    SimpleDateFormat dateFormat=new SimpleDateFormat("MMMM yyyy",Locale.ENGLISH);
    SimpleDateFormat monthFormat=new SimpleDateFormat("MMMM",Locale.ENGLISH);
    SimpleDateFormat yearFormat=new SimpleDateFormat("yyyy",Locale.ENGLISH);
    SimpleDateFormat eventDateFormat=new SimpleDateFormat("yyyy-MM-dd",Locale.ENGLISH);
    String[] pump = { "Pump One", "Pump Two", "Pump Three", "Pump Four", };
    String[] action = {  "On", "Off"};
    AlertDialog  alertDialog;
    private DBOpenHelper dbOpenHelper;
    MyGridAdapter myGridAdapter;

    int alarmYear,alarmMonth,alarmDay,alarmHour,alarmMinutes;


    public CustomCalendarView(Context context) {
        super(context);
    }

    public CustomCalendarView(final Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        this.context=context;
        InitializeLayout();
        SetupCalendar();
        previousBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                calendar.add(Calendar.MONTH,-1);
                SetupCalendar();
            }
        });
        nextBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                calendar.add(Calendar.MONTH,1);
                SetupCalendar();
            }
        });

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {





                AlertDialog.Builder builder=new AlertDialog.Builder(context);
                builder.setCancelable(true);
                final View addView=LayoutInflater.from(parent.getContext()).inflate(R.layout.add_new_event_layout,null);
                final EditText etEventName=addView.findViewById(R.id.etEventName);
                final TextView EventTime=addView.findViewById(R.id.eventtime);
                Button AddEvent=addView.findViewById(R.id.addEVent);
                final CheckBox alarmMe=addView.findViewById(R.id.alarmme);


                Calendar dateCalendar=Calendar.getInstance();
                dateCalendar.setTime(dates.get(position));
                alarmYear=dateCalendar.get(Calendar.YEAR);
                alarmMonth=dateCalendar.get(Calendar.MONTH);
                alarmDay=dateCalendar.get(Calendar.DAY_OF_MONTH);





                EventTime.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Calendar calendar=Calendar.getInstance();
                        int hours=calendar.get(Calendar.HOUR_OF_DAY);
                        int minutes=calendar.get(Calendar.MINUTE);
                        TimePickerDialog timePickerDialog=new TimePickerDialog(addView.getContext(), new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                Calendar c=Calendar.getInstance();
                                c.set(Calendar.HOUR_OF_DAY,hourOfDay);
                                c.set(Calendar.MINUTE,minute);
                                c.setTimeZone(TimeZone.getDefault());
                                SimpleDateFormat hFormat=new SimpleDateFormat("K:mm a",Locale.ENGLISH);
                                String event_time=hFormat.format(c.getTime());
                                EventTime.setText(event_time);
                                alarmHour=c.get(Calendar.HOUR_OF_DAY);
                                alarmMinutes=c.get(Calendar.MINUTE);




                            }
                        },hours,minutes,false);
                        timePickerDialog.show();
                   }
                });

                final String date =eventDateFormat.format(dates.get(position));
                final String month =monthFormat.format(dates.get(position));
                final String year =yearFormat.format(dates.get(position));


                AddEvent.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        RadioButton rb1,rb2,rb3,rb4;
                        RadioButton rb_on,rb_off;
                        rb1=addView.findViewById(R.id.rb1);
                        rb2=addView.findViewById(R.id.rb2);
                        rb3=addView.findViewById(R.id.rb3);
                        rb4=addView.findViewById(R.id.rb4);
                        rb_off=addView.findViewById(R.id.rb_off);
                        rb_on=addView.findViewById(R.id.rb_on);
                        String option="";
                        String  action="";
                        if (rb1.isChecked()){
                            option="1";
                        }else if (rb2.isChecked()){
                            option="2";
                        }else if (rb3.isChecked()){
                            option="3";
                        }else if (rb4.isChecked()){
                            option="4";
                        }

                        if (rb_on.isChecked()){
                            action="1";
                        }else  if (rb_off.isChecked()){
                            action="0";
                        }



                        String eventname=etEventName.getText().toString();
                        String eventtime=EventTime.getText().toString();

                        //todo
                        if (alarmMe.isChecked())
                        {
                            if (TextUtils.isEmpty(eventname))
                            {
                                etEventName.setError("Add task name");
                            }
                            else if (TextUtils.isEmpty(eventtime))
                            {
                                Toast.makeText(context, "Please select time...", Toast.LENGTH_SHORT).show();
                            }else {


                                if (!TextUtils.isEmpty(option) && !TextUtils.isEmpty(action)){
                                    SaveEvent(eventname, eventtime, date, month, year, "0","on",option,action);
                                    SetupCalendar();
                                    Calendar calendar=Calendar.getInstance();
                                    calendar.set(alarmYear,alarmMonth,alarmDay,alarmHour,alarmMinutes);
                                    setAlarm(calendar,eventname,eventtime,getRequestCode(date,eventname,eventtime));
                                    alertDialog.dismiss();
                                }else {
                                    Toast.makeText(context, "Check your pumps and actions.", Toast.LENGTH_SHORT).show();
                                }
                            }

                        }else {
                            if (TextUtils.isEmpty(eventname))
                            {
                                etEventName.setError("Add task name");
                            }
                            else if (TextUtils.isEmpty(eventtime))
                            {
                                Toast.makeText(context, "Please select time...", Toast.LENGTH_SHORT).show();
                            }else {

                                SaveEvent(eventname, eventtime, date, month, year, "0","off",option,action);
                                SetupCalendar();
                                alertDialog.dismiss();
                            }

                        }


                    }
                });

                builder.setView(addView);
                alertDialog=builder.create();
                alertDialog.show();

            }
        });

        gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                String date=eventDateFormat.format(dates.get(position));
                AlertDialog.Builder builder=new AlertDialog.Builder(context);
                builder.setCancelable(true);
                View showView=LayoutInflater.from(parent.getContext()).inflate(R.layout.show_events_layout,null);
                RecyclerView recyclerView=showView.findViewById(R.id.EventRV);
                RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(showView.getContext());
                recyclerView.setLayoutManager(layoutManager);
                recyclerView.setHasFixedSize(true);
                EventRecyclerAdapter eventRecyclerAdapter=new EventRecyclerAdapter(showView.getContext(), CollectEventsByDate(date));

                recyclerView.setAdapter(eventRecyclerAdapter);
                eventRecyclerAdapter.notifyDataSetChanged();
                builder.setView(showView);
                alertDialog=builder.create();
                    alertDialog.show();
                    alertDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                        @Override
                        public void onCancel(DialogInterface dialog) {
                            SetupCalendar();
                        }
                    });



                return true;
            }
        });
    }
    private void SaveEvent(String event, String time, String date, String month, String year, String status, String notify, String option, String action)
    {
        dbOpenHelper=new DBOpenHelper(context);
        SQLiteDatabase database=dbOpenHelper.getWritableDatabase();
        dbOpenHelper.SaveEvent(event,time,date,month,year,status,notify,database);
        dbOpenHelper.close();
        saveToFirebase(time,date,month,status,option);
        //Toast.makeText(context, "Task Saved.", Toast.LENGTH_SHORT).show();
    }

    private void saveToFirebase(String time, String date, String month, String status, String option) {


        String dbroot = "BRAINVERSE/IOTIRRIGATION/PUMPS";
        DatabaseReference pumpsDb= FirebaseDatabase.getInstance().getReference().child(dbroot);

        String tarehe=date+" "+month+" "+time;
        pumpsDb.child(option).setValue(status).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()){

                    Toast.makeText(context, "Schedule saved successfully.", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(context, "An error occured.", Toast.LENGTH_SHORT).show();

                }
            }
        });

    }


    private ArrayList<Events> CollectEventsByDate(String date)
    {
        ArrayList<Events> arrayList=new ArrayList<>();
        dbOpenHelper=new DBOpenHelper(context);
        SQLiteDatabase database=dbOpenHelper.getReadableDatabase();
        Cursor cursor=dbOpenHelper.ReadEvents(date,database);
        while (cursor.moveToNext())
        {
            String event=cursor.getString(cursor.getColumnIndex(DBStructure.EVENT));
            String time=cursor.getString(cursor.getColumnIndex(DBStructure.TIME));
            String Date=cursor.getString(cursor.getColumnIndex(DBStructure.DATE));
            String month=cursor.getString(cursor.getColumnIndex(DBStructure.MONTH));
            String yea=cursor.getString(cursor.getColumnIndex(DBStructure.YEAR));
            String status=cursor.getString(cursor.getColumnIndex(DBStructure.EVENT_STATUS));
            Events events=new Events(event,time,Date,month,yea,status);
            arrayList.add(events);

        }
        cursor.close();
        dbOpenHelper.close();
        return arrayList;
    }

    public CustomCalendarView(Context context, @Nullable AttributeSet attrs ,int defAttrStyle) {
        super(context, attrs,defAttrStyle);
    }

    private void InitializeLayout()

    {
        LayoutInflater inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view=inflater.inflate(R.layout.calendar_layout,this);
        nextBtn=view.findViewById(R.id.btnNext);
        previousBtn=view.findViewById(R.id.btnPrevious);
        tvCurrentDate=view.findViewById(R.id.tvCurrentDate);
        gridView=view.findViewById(R.id.calendar_grid);

    }
    private void SetupCalendar()
    {
        String currentDate=dateFormat.format(calendar.getTime());
        tvCurrentDate.setText(currentDate);
        dates.clear();
        Calendar monthCalendar= (Calendar) calendar.clone();
        monthCalendar.set(Calendar.DAY_OF_MONTH,1);
        int FirstDayOfMonth=monthCalendar.get(Calendar.DAY_OF_WEEK)-1;
        monthCalendar.add(Calendar.DAY_OF_MONTH,-FirstDayOfMonth);

        CollectEventsPerMonth(monthFormat.format(calendar.getTime()),yearFormat.format(calendar.getTime()));
        while (dates.size()<MAX_CALENDAR_DATES)
        {
            dates.add(monthCalendar.getTime());
            monthCalendar.add(Calendar.DAY_OF_MONTH,1);

        }
        myGridAdapter=new MyGridAdapter(context,dates,calendar,eventsList);
        gridView.setAdapter(myGridAdapter);

    }
    private void CollectEventsPerMonth(String Month,String year)
    {
        eventsList.clear();
        dbOpenHelper=new DBOpenHelper(context);
        SQLiteDatabase database=dbOpenHelper.getReadableDatabase();
        Cursor cursor=dbOpenHelper.ReadEventsPerMonth(Month,year,database);
        while (cursor.moveToNext())
        {
            String event=cursor.getString(cursor.getColumnIndex(DBStructure.EVENT));
            String time=cursor.getString(cursor.getColumnIndex(DBStructure.TIME));

            String date=cursor.getString(cursor.getColumnIndex(DBStructure.DATE));
            String month=cursor.getString(cursor.getColumnIndex(DBStructure.MONTH));
            String yea=cursor.getString(cursor.getColumnIndex(DBStructure.YEAR));
            String status=cursor.getString(cursor.getColumnIndex(DBStructure.EVENT_STATUS));
            Events events=new Events(event,time,date,month,yea,status);
            eventsList.add(events);

        }
        cursor.close();
        dbOpenHelper.close();
    }

    private void setAlarm(Calendar calendar, String event, String tim, int RequestCode)
    {
        Intent intent=new Intent(context.getApplicationContext(),AlarmReciever.class);
        intent.putExtra("event",event);
        intent.putExtra("time",tim);
        intent.putExtra("id",RequestCode);

        PendingIntent pendingIntent=PendingIntent.getBroadcast(context,RequestCode,intent,PendingIntent.FLAG_ONE_SHOT);
        AlarmManager alarmManager=(AlarmManager)context.getApplicationContext().getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP,calendar.getTimeInMillis(),pendingIntent);


    }

    private int getRequestCode(String date,String event,String time)
    {
        int code=0;
        dbOpenHelper=new DBOpenHelper(context);
        SQLiteDatabase database=dbOpenHelper.getReadableDatabase();
        Cursor cursor=dbOpenHelper.ReadIDEvents(date,event,time,database);
        while (cursor.moveToNext())
        {
           code=cursor.getInt(cursor.getColumnIndex(DBStructure.ID));
        }
        cursor.close();
        dbOpenHelper.close();
        return code;
    }
}

