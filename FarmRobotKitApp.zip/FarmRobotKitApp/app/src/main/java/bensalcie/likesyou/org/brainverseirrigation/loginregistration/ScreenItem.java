package bensalcie.likesyou.org.brainverseirrigation.loginregistration;

public class ScreenItem {
    String Ttile,Description;
    int ScreenImg;
    int backgound_style;

    public int getBackgound_style() {
        return backgound_style;
    }

    public void setBackgound_style(int backgound_style) {
        this.backgound_style = backgound_style;
    }

    public ScreenItem(String patient_, String login_page_, int profile, int backgound_style) {
        this.backgound_style = backgound_style;
    }

    public String getTtile() {
        return Ttile;
    }

    public void setTtile(String ttile) {
        Ttile = ttile;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public int getScreenImg() {
        return ScreenImg;
    }

    public void setScreenImg(int screenImg) {
        ScreenImg = screenImg;
    }

    public ScreenItem(String ttile, String description, int screenImg) {
        Ttile = ttile;
        Description = description;
        ScreenImg = screenImg;
    }
}
