package bensalcie.likesyou.org.brainverseirrigation.loginregistration;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import bensalcie.likesyou.org.brainverseirrigation.MainActivity;
import bensalcie.likesyou.org.brainverseirrigation.R;

public class ReusableActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;

private FragmentTransaction ft;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reusable);
        getSupportActionBar().hide();
        mAuth=FirebaseAuth.getInstance();
         ft=getSupportFragmentManager().beginTransaction();
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser currentUser=mAuth.getCurrentUser();
        if (currentUser==null){
            LoginFragment lf=new LoginFragment();
            ft.replace(R.id.reusable_layout,lf);
            ft.addToBackStack("login");
            ft.commit();

        }else {
            startActivity(new Intent(ReusableActivity.this, MainActivity.class));
            finish();
        }

    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

}
