package bensalcie.likesyou.org.brainverseirrigation.loginregistration;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import java.util.List;

import bensalcie.likesyou.org.brainverseirrigation.R;

public class IntroViewPagerAdapter extends PagerAdapter {
    Context context;
    List<ScreenItem> mListScreen;

    public IntroViewPagerAdapter(Context context, List<ScreenItem> mListScreen) {
        this.context = context;
        this.mListScreen = mListScreen;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        LayoutInflater inflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        assert inflater != null;
        View layoutSreen=inflater.inflate(R.layout.another_layout,null);
        LinearLayout introHolder=layoutSreen.findViewById(R.id.page_holder);
        introHolder.setBackgroundResource(mListScreen.get(position).getBackgound_style());
        ImageView img=layoutSreen.findViewById(R.id.intro_img);
        TextView title=layoutSreen.findViewById(R.id.intro_ttl);
        TextView desc=layoutSreen.findViewById(R.id.intro_desc);
        title.setText(mListScreen.get(position).getTtile());
        desc.setText(mListScreen.get(position).getDescription());
        img.setImageResource(mListScreen.get(position).getScreenImg());
        container.addView(layoutSreen);


        return layoutSreen;
    }

    @Override
    public int getCount() {
        return mListScreen.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view==object;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View)object);
    }
}
