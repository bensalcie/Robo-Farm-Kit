package bensalcie.likesyou.org.brainverseirrigation.loginregistration;


import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import org.w3c.dom.Text;

import bensalcie.likesyou.org.brainverseirrigation.MainActivity;
import bensalcie.likesyou.org.brainverseirrigation.R;


public class LoginFragment extends Fragment {
private View v;
private TextView tvSignup;
private EditText etEmail,etPassword;
private Button btnLogin;
private FirebaseAuth mAuth;

    public LoginFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v= inflater.inflate(R.layout.fragment_login, container, false);
        tvSignup=v.findViewById(R.id.tvLogin);
        btnLogin=v.findViewById(R.id.btnLogin);
        etEmail=v.findViewById(R.id.etEmail);
        etPassword=v.findViewById(R.id.etPassword);

        mAuth=FirebaseAuth.getInstance();


        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnLogin.setText("Please wait...");
                String email=etEmail.getText().toString();
                String pas=etPassword.getText().toString();
                if (TextUtils.isEmpty(email)){
                    etEmail.setError("Check");
                    if (TextUtils.isEmpty(pas)){
                        etPassword.setError("Check");
                    }
                }else {
                    mAuth.signInWithEmailAndPassword(email,pas).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if (task.isSuccessful()){
                                btnLogin.setText("Success");

                                startActivity(new Intent(getActivity(), MainActivity.class));
                                getActivity().finish();

                            }else {
                                btnLogin.setError("Error occured");
                            }
                        }
                    });
                }


            }
        });
        tvSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegisterFragment rf=new RegisterFragment();
                assert getFragmentManager() != null;
                FragmentTransaction ft=getFragmentManager().beginTransaction();
                ft.replace(R.id.reusable_layout,rf);
                ft.addToBackStack("register");
                ft.commit();
            }
        });
        return v;
    }


}
