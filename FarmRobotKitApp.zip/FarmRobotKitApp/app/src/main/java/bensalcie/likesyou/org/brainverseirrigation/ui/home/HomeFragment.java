package bensalcie.likesyou.org.brainverseirrigation.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.hadiidbouk.charts.BarData;
import com.hadiidbouk.charts.ChartProgressBar;

import org.eazegraph.lib.charts.ValueLineChart;
import org.eazegraph.lib.models.ValueLinePoint;
import org.eazegraph.lib.models.ValueLineSeries;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import bensalcie.likesyou.org.brainverseirrigation.R;
import me.itangqi.waveloadingview.WaveLoadingView;
import pl.droidsonroids.gif.GifImageView;

public class HomeFragment extends Fragment {

    private View root;
    private ChartProgressBar mChart;
    private DatabaseReference analyticsDb;
    private String dbRoot="BRAINVERSE/IOTIRRIGATION";
    private      String today="Mon";
    private CardView tempHolder,humHolder,perfomCard,moisturecontent,activityHolder;
    private  double []tTay =new double[7];
    private  double []hTay =new double[7];
    private  double []activityLog =new double[7];
    private GifImageView loadingView;




    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
         root = inflater.inflate(R.layout.fragment_home, container, false);
         mChart=root.findViewById(R.id.ChartProgressBar);
         tempHolder=root.findViewById(R.id.tempHolder);
         humHolder=root.findViewById(R.id.humHolder);
        perfomCard=root.findViewById(R.id.perfomCard);
        moisturecontent=root.findViewById(R.id.moisturecontent);
        activityHolder=root.findViewById(R.id.activityHolder);
        loadingView=root.findViewById(R.id.loadingView);
        today=getTodaysShortForm();
        analyticsDb= FirebaseDatabase.getInstance().getReference().child(dbRoot);
        createTempHumValues(today);





        return root;
    }

    private String getTodaysShortForm() {
        SimpleDateFormat sdf=new SimpleDateFormat("EEE");
        Date d=new Date();
        return sdf.format(d);
    }

    private void createTempHumValues(final String today) {
        loadingView.setVisibility(View.VISIBLE);
        final TextView tvTemp,tvHum;
        tvHum=root.findViewById(R.id.tvHum);
        tvTemp=root.findViewById(R.id.tvTemp);

        analyticsDb.child("SENSORS/DHT").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
               if (dataSnapshot.exists()){
                   String  tem=dataSnapshot.child("T/"+today).getValue().toString();
                   String  hum=dataSnapshot.child("H/"+today).getValue().toString();
                   //get temperatures over the week

                   String tmon=dataSnapshot.child("T/Mon").getValue().toString();
                   tTay[0]=Double.parseDouble(tmon);
                   String ttue=dataSnapshot.child("T/Tue").getValue().toString();
                   tTay[1]=Double.parseDouble(ttue);
                   String twed= dataSnapshot.child("T/Wed").getValue().toString();
                   tTay[2]=Double.parseDouble(twed);
                   String tthur=dataSnapshot.child("T/Thur").getValue().toString();
                   tTay[3]=Double.parseDouble(tthur);
                   String tfri=dataSnapshot.child("T/Fri").getValue().toString();
                   tTay[4]=Double.parseDouble(tfri);
                   String tsat=dataSnapshot.child("T/Sat").getValue().toString();
                   tTay[5]=Double.parseDouble(tsat);
                   String tsun=dataSnapshot.child("T/Sun").getValue().toString();
                   tTay[6]=Double.parseDouble(tsun);


                   String hmon=dataSnapshot.child("H/Mon").getValue().toString();
                   hTay[0]=Double.parseDouble(hmon);
                   String htue=dataSnapshot.child("H/Tue").getValue().toString();
                   hTay[1]=Double.parseDouble(htue);
                   String hwed= dataSnapshot.child("H/Wed").getValue().toString();
                   hTay[2]=Double.parseDouble(hwed);
                   String hthur=dataSnapshot.child("H/Thur").getValue().toString();
                   hTay[3]=Double.parseDouble(hthur);
                   String hfri=dataSnapshot.child("H/Fri").getValue().toString();
                   hTay[4]=Double.parseDouble(hfri);
                   String hsat=dataSnapshot.child("H/Sat").getValue().toString();
                   hTay[5]=Double.parseDouble(hsat);
                   String hsun=dataSnapshot.child("H/Sun").getValue().toString();
                   hTay[6]=Double.parseDouble(hsun);
                   createChart();

                   double temm=Double.parseDouble(tem);
                   double humm=Double.parseDouble(hum);


                   tvTemp.setText(" "+temm+"\u00B0"+"C" );
                   tvHum.setText(""+humm+"\u00B0"+"F");
                   tempHolder.setVisibility(View.VISIBLE);
                   humHolder.setVisibility(View.VISIBLE);
               }


            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    private void createWaterLevel() {
        moisturecontent.setVisibility(View.VISIBLE);

        analyticsDb.child("SENSORS/MOISTURE/"+today).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                String  level=dataSnapshot.getValue().toString();
                double db=Double.parseDouble(level);

                WaveLoadingView wlv=root.findViewById(R.id.waveLoadingView);
                wlv.setProgressValue((int) db);
                wlv.startAnimation();
                }else {
                    WaveLoadingView wlv=root.findViewById(R.id.waveLoadingView);
                    wlv.setProgressValue(0);
                    wlv.startAnimation();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        createTimeChart();

    }

    private void createTimeChart() {
        final ValueLineChart mCubicValueLineChart = root.findViewById(R.id.cubiclinechart);

        final ValueLineSeries series = new ValueLineSeries();
        series.setColor(0xFF56B7F1);

        analyticsDb.child("ACTIVITY/" + today).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String a8 = dataSnapshot.child("8").getValue().toString();
                    String a10 = dataSnapshot.child("10").getValue().toString();
                    String a12 = dataSnapshot.child("12").getValue().toString();
                    String a14 = dataSnapshot.child("14").getValue().toString();
                    String a16 = dataSnapshot.child("16").getValue().toString();
                    String a18 = dataSnapshot.child("18").getValue().toString();
                    String a20 = dataSnapshot.child("20").getValue().toString();

                    activityLog[0] = Double.parseDouble(a8);
                    activityLog[1] = Double.parseDouble(a10);
                    activityLog[2] = Double.parseDouble(a12);
                    activityLog[3] = Double.parseDouble(a14);
                    activityLog[4] = Double.parseDouble(a16);
                    activityLog[5] = Double.parseDouble(a18);
                    activityLog[6] = Double.parseDouble(a20);

                    series.addPoint(new ValueLinePoint("8", (float) (activityLog[0])));
                    series.addPoint(new ValueLinePoint("10", (float) (activityLog[1])));
                    series.addPoint(new ValueLinePoint("12", (float) (activityLog[2])));
                    series.addPoint(new ValueLinePoint("2", (float) (activityLog[3])));
                    series.addPoint(new ValueLinePoint("4", (float) (activityLog[4])));
                    series.addPoint(new ValueLinePoint("6", (float) (activityLog[5])));
                    series.addPoint(new ValueLinePoint("8", (float) (activityLog[6])));
                    mCubicValueLineChart.addSeries(series);
                    mCubicValueLineChart.isUseDynamicScaling();
                    activityHolder.setVisibility(View.VISIBLE);
                    loadingView.setVisibility(View.GONE);
                    mCubicValueLineChart.startAnimation();
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


    }

    private void createChart() {
        ArrayList<BarData> dataList = new ArrayList<>();
        BarData data = new BarData("Mon", (float) (hTay[0]/tTay[0]), "");
        dataList.add(data);

        data = new BarData("Tue", (float) (hTay[1]/tTay[1]), "");
        dataList.add(data);

        data = new BarData("Wed", (float) (hTay[2]/tTay[2]), "");
        dataList.add(data);

        data = new BarData("Thur",(float) (hTay[3]/tTay[3]), "");
        dataList.add(data);

        data = new BarData("Fri", (float) (hTay[4]/tTay[4]), "");
        dataList.add(data);

        data = new BarData("Sat", (float) (hTay[5]/tTay[5]), "");
        dataList.add(data);
        data = new BarData("Sun",(float) (hTay[6]/tTay[6]), "");
        dataList.add(data);

        mChart.setDataList(dataList);
        mChart.build();
        perfomCard.setVisibility(View.VISIBLE);
        createWaterLevel();


    }
}