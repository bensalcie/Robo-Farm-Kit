package bensalcie.likesyou.org.brainverseirrigation.loginregistration;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import bensalcie.likesyou.org.brainverseirrigation.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class IntroFragment extends Fragment {
    private View v;
    private ViewPager screenPager;
    IntroViewPagerAdapter introViewPagerAdapter;

    public IntroFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v= inflater.inflate(R.layout.fragment_intro, container, false);
        screenPager=v.findViewById(R.id.screen_pager);
        //add items to the list
        final List<ScreenItem> mList=new ArrayList<>();
        mList.add(new ScreenItem("Access all your farm information on one platform ","Login page ",0,R.drawable.background_patient_page));
        mList.add(new ScreenItem("Welcome to contact Tracing","Swipe left to login as patient.\nSwipe Right to login as medical attendant",R.drawable.ava,R.drawable.background_patient_page));
        mList.add(new ScreenItem("Medical Professional","Login page",R.drawable.ava,R.drawable.background_patient_page));
        //setup viewpager
        introViewPagerAdapter=new IntroViewPagerAdapter(getContext(),mList);
        screenPager.setAdapter(introViewPagerAdapter);
        screenPager.setCurrentItem(1);
        return v;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
