package bensalcie.likesyou.org.brainverseirrigation;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import bensalcie.likesyou.org.brainverseirrigation.ui.dashboard.DashboardFragment;
import bensalcie.likesyou.org.brainverseirrigation.ui.home.HomeFragment;
import bensalcie.likesyou.org.brainverseirrigation.ui.notifications.NotificationsFragment;

public class MainActivity extends AppCompatActivity {
    private LinearLayout menu_one,menu_two,menu_three;
    private TextView tvInsights,tvAnalysys,tvControls;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        assert getSupportActionBar()!=null;
        getSupportActionBar().hide();
        menu_one=findViewById(R.id.menu_one);
        menu_two=findViewById(R.id.menu_two);
        menu_three=findViewById(R.id.menu_three);
        tvAnalysys=findViewById(R.id.tvAnalysis);
        tvInsights=findViewById(R.id.tvInsights);
        tvControls=findViewById(R.id.tvControls);

        menu_one.setBackgroundColor(Color.parseColor("#30471A"));
        tvAnalysys.setTextColor(Color.parseColor("#6A8831"));
        HomeFragment hf=new HomeFragment();
        FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.nav_host_fragment,hf);
        ft.commit();
        menu_one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                menu_one.setBackgroundColor(Color.parseColor("#30471A"));
                tvAnalysys.setTextColor(Color.parseColor("#6A8831"));
                settupInit(menu_two,menu_three);
                HomeFragment hf=new HomeFragment();
                FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.nav_host_fragment,hf);
                ft.commit();



            }
        });
        menu_two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                menu_two.setBackgroundColor(Color.parseColor("#30471A"));
                tvControls.setTextColor(Color.parseColor("#6A8831"));
                settupInit(menu_one,menu_three);
                DashboardFragment hf=new DashboardFragment();
                FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.nav_host_fragment,hf);
                ft.commit();


            }
        });
        menu_three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                menu_three.setBackgroundColor(Color.parseColor("#30471A"));
                tvInsights.setTextColor(Color.parseColor("#6A8831"));
                settupInit(menu_one,menu_two);
                NotificationsFragment hf=new NotificationsFragment();
                FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.nav_host_fragment,hf);
                ft.commit();


            }
        });



    }

    private void settupInit(LinearLayout menu_o, LinearLayout menu_t) {
        menu_o.setBackgroundColor(0);
        menu_t.setBackgroundColor(0);
    }

}
