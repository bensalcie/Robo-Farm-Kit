package bensalcie.likesyou.org.brainverseirrigation.schedular;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import bensalcie.likesyou.org.brainverseirrigation.R;

public class EventRecyclerAdapter extends RecyclerView.Adapter<EventRecyclerAdapter.MyViewHolder> {

    Context context;
    ArrayList<Events>arrayList;
    DBOpenHelper dbOpenHelper;

    public EventRecyclerAdapter(Context context,ArrayList<Events>arrayList) {
        this.context = context;
        this.arrayList=arrayList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.show_events_row_layout,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        final Events events=arrayList.get(position);
        holder.Event.setText(events.getEVENT());
        holder.DateTxt.setText(events.getDATE());


        if (events.getSTATUS().equals("0"))
        {
            holder.Time.setText(events.getTIME()+"\n Status: "+"On");
            holder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked)
                    {
                        //update  status values.
                        updateEventStatus(events.getDATE(),events.getEVENT(),events.getTIME(),"1");
                        //events.setSTATUS("1");
                        notifyDataSetChanged();
                    }else {
                        //update  status values.
                        updateEventStatus(events.getDATE(),events.getEVENT(),events.getTIME(),"0");
                        //events.setSTATUS("1");
                        notifyDataSetChanged();
                    }
                }
            });



        }else {
            holder.Time.setText(events.getTIME()+"\n Status: "+"Done");
            holder.checkBox.setText("Done");
            holder.checkBox.setChecked(true);
            //holder.holder_layout.setBackgroundColor(context.getResources().getColor(R.color.color_grey));


        }





        holder.tvDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteCalendarEvent(events.getEVENT(),events.getDATE(),events.getTIME(),events.getSTATUS());
                arrayList.remove(position);
                notifyDataSetChanged();
            }
        });


        if (isAlarmed(events.getDATE(),events.getEVENT(),events.getTIME()))
        {
            holder.setAlarm.setImageResource(R.drawable.ic_notifications_active_black_24dp);
            //notifyDataSetChanged();
        }else {
            holder.setAlarm.setImageResource(R.drawable.ic_notifications_off_black_24dp);
            //notifyDataSetChanged();
        }

        Calendar dateCalendar=Calendar.getInstance();
        dateCalendar.setTime(ConvertStringToDate(events.getDATE()));
        final int alarmYear=dateCalendar.get(Calendar.YEAR);
        final int alarMonth=dateCalendar.get(Calendar.MONTH);
        final int alarDay=dateCalendar.get(Calendar.DAY_OF_MONTH);

        Calendar timeCalendar=Calendar.getInstance();
        timeCalendar.setTime(ConvertStringToTime(events.getTIME()));
        final int alarmHour=timeCalendar.get(Calendar.HOUR_OF_DAY);
        final int alarmMinute=timeCalendar.get(Calendar.MINUTE);


        holder.setAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isAlarmed(events.getDATE(),events.getEVENT(),events.getTIME()))
                {
                    holder.setAlarm.setImageResource(R.drawable.ic_notifications_off_black_24dp);
                    cancelAlarm(getRequestCode(events.getDATE(),events.getEVENT(),events.getTIME()));
                    updateEvent(events.getDATE(),events.getEVENT(),events.getTIME(),"off","1");
                    notifyDataSetChanged();


                }else {
                    holder.setAlarm.setImageResource(R.drawable.ic_notifications_active_black_24dp);
                    Calendar alarmCalendar=Calendar.getInstance();
                    alarmCalendar.set(alarmYear,alarMonth,alarDay,alarmHour,alarmMinute);
                    setAlarm(alarmCalendar,events.getEVENT(),events.getTIME(),getRequestCode(events.getDATE(),events.getEVENT(),events.getTIME()));
                    updateEvent(events.getDATE(),events.getEVENT(),events.getTIME(),"on","0");
                    notifyDataSetChanged();

                }
            }
        });


    }

    private void deleteCalendarEvent(String event,String date,String time,String state)
    {
        dbOpenHelper=new DBOpenHelper(context);
        SQLiteDatabase database = dbOpenHelper.getReadableDatabase();
        dbOpenHelper.deleteEvent(event,date,time,state,database);
        dbOpenHelper.close();


    }

    private Date ConvertStringToTime(String eventDate)
    {
        SimpleDateFormat format=new SimpleDateFormat("kk:mm", Locale.ENGLISH);
        Date date=null;
        try{
            date=format.parse(eventDate);

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }
    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView DateTxt,Event,Time,tvDelete;
        CheckBox checkBox;
        ImageView setAlarm;
        LinearLayout holder_layout;


        public MyViewHolder(View itemView) {
            super(itemView);
            DateTxt=itemView.findViewById(R.id.eventdate);
            Event=itemView.findViewById(R.id.eventname);
            Time=itemView.findViewById(R.id.eventtime);
            checkBox=itemView.findViewById(R.id.checkbox);
            tvDelete=itemView.findViewById(R.id.tv_delete);
            setAlarm=itemView.findViewById(R.id.imageNotification);
            holder_layout=itemView.findViewById(R.id.holder_layout);

        }
    }

    private boolean isAlarmed(String date,String event,String time)
    {
        boolean alarmed=false;
        dbOpenHelper=new DBOpenHelper(context);
        SQLiteDatabase database=dbOpenHelper.getReadableDatabase();
        Cursor cursor=dbOpenHelper.ReadIDEvents(date,event,time,database);
        while (cursor.moveToNext())
        {
            String notify=cursor.getString(cursor.getColumnIndex(DBStructure.Notify));
            if (notify.equals("on"))
            {
                alarmed=true;
            }else {
                alarmed=false;
            }
        }
        cursor.close();
        dbOpenHelper.close();
        return alarmed;
    }
    private void setAlarm(Calendar calendar, String event, String tim, int RequestCode)
    {
        Intent intent=new Intent(context.getApplicationContext(),AlarmReciever.class);
        intent.putExtra("event",event);
        intent.putExtra("time",tim);
        intent.putExtra("id",RequestCode);

        PendingIntent pendingIntent=PendingIntent.getBroadcast(context,RequestCode,intent,PendingIntent.FLAG_ONE_SHOT);
        AlarmManager alarmManager=(AlarmManager)context.getApplicationContext().getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP,calendar.getTimeInMillis(),pendingIntent);


    }
    private void cancelAlarm(int RequestCode)
    {
        Intent intent=new Intent(context.getApplicationContext(),AlarmReciever.class);
         PendingIntent pendingIntent=PendingIntent.getBroadcast(context,RequestCode,intent,PendingIntent.FLAG_ONE_SHOT);
        AlarmManager alarmManager=(AlarmManager)context.getApplicationContext().getSystemService(Context.ALARM_SERVICE);
        alarmManager.cancel(pendingIntent);


    }

    private int getRequestCode(String date,String event,String time)
    {
        int code=0;
        dbOpenHelper=new DBOpenHelper(context);
        SQLiteDatabase database=dbOpenHelper.getReadableDatabase();
        Cursor cursor=dbOpenHelper.ReadIDEvents(date,event,time,database);
        while (cursor.moveToNext())
        {
            code=cursor.getInt(cursor.getColumnIndex(DBStructure.ID));
        }
        cursor.close();
        dbOpenHelper.close();
        return code;
    }

    private void  updateEvent(String date,String event,String time,String notify,String status)
    {
        dbOpenHelper=new DBOpenHelper(context);
        SQLiteDatabase database=dbOpenHelper.getWritableDatabase();
        dbOpenHelper.updateEvent(date,event,time,notify,status,database);
        dbOpenHelper.close();
    }


    private Date ConvertStringToDate(String eventDate)
    {
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
        Date date=null;
        try{
            date=format.parse(eventDate);

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }
    private void  updateEventStatus(String date,String event,String time,String status)
    {
        dbOpenHelper=new DBOpenHelper(context);
        SQLiteDatabase database=dbOpenHelper.getWritableDatabase();
        dbOpenHelper.updateEventStatus(date,event,time,status,database);
        dbOpenHelper.close();
    }

}
